Functions used in the courses in Actuarial Sciences at Unifal-Brazil.
